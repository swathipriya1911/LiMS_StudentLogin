package com.lims.studentlogin.dto;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lims.studentlogin.exception.LibraryException;
import com.lims.studentlogin.service.ILibraryService;
import com.lims.studentlogin.service.LibraryServiceImpl;



/**
 * Servlet implementation class LibraryInterface
 */
@WebServlet("/LibraryInterface")
public class LibraryInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LibraryInterface() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out= response.getWriter();
		RequestDispatcher dispatch=null;
		HttpSession session=request.getSession();  
		ILibraryService libraryServiceImpl=new LibraryServiceImpl();
		String id=request.getParameter("id");
		String password=request.getParameter("pwd");
		session.setAttribute("id",id);
		String option=request.getParameter("action");
		if(option!=null && option.equals("search"))
		{
			dispatch=request.getRequestDispatcher("/search.jsp");
			dispatch.forward(request, response);
		}
		else if(option!=null && option.equals("request"))
		{
			dispatch=request.getRequestDispatcher("/request.jsp");
			dispatch.forward(request, response);
		}
		else if(option!=null && option.equals("return"))
		{
			dispatch=request.getRequestDispatcher("/returnbook.jsp");
			dispatch.forward(request, response);
		}
		else if(option!=null && option.equals("Return Book"))
		{
			String transactionId=request.getParameter("transid");
			String bookId=request.getParameter("bookid");
			int fine=0;
			try {
				fine = libraryServiceImpl.returnBook(transactionId,bookId);
			} catch (LibraryException e) {
				e.printStackTrace();
			}
			request.setAttribute("fine", fine);
			dispatch=request.getRequestDispatcher("/SuccessfulReturn.jsp");
			dispatch.include(request, response);
			//out.println("Your book is returned successfully and your fine is "+fine);
		}
		else if(option!=null && option.equals("Request Book"))
		{
			int value=0;
			String bookid=request.getParameter("bookid");
			try {
				value=libraryServiceImpl.isBookAvailable(bookid);
			} catch (LibraryException e) {
				e.printStackTrace();
			}
			if(value==1)
			{
			dispatch=request.getRequestDispatcher("/placeRequest.jsp");
			dispatch.include(request, response);
			if(option!=null && option.equals("Yes"))
			{
				try {
					int registrationId=libraryServiceImpl.addRequest(id,bookid);
				    if(registrationId==0)
				    {
				      dispatch=request.getRequestDispatcher("/moreRequest.jsp");
				      dispatch.forward(request, response);
				    }
				    else
				    {
				      request.setAttribute("regId", registrationId);
				      dispatch=request.getRequestDispatcher("/genRegId.jsp");
					  dispatch.forward(request, response);
				    }
				} catch (LibraryException e) {
					e.printStackTrace();
				}
			}
			else if(option!=null && option.equals("No"))
			{
				dispatch=request.getRequestDispatcher("/NoRequest.jsp");
				dispatch.forward(request, response);
			}
			}
			else if(value==2)
			{
				dispatch=request.getRequestDispatcher("/OutOfCopies.jsp");
				dispatch.forward(request, response);
				
			}
			else if(value==3)
			{
				dispatch=request.getRequestDispatcher("/Error.jsp");
				dispatch.forward(request, response);
				
			}	
		}
    }	

}
