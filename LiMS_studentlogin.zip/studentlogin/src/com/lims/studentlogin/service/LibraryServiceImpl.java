package com.lims.studentlogin.service;

import com.lims.studentlogin.dao.ILibraryDao;
import com.lims.studentlogin.dao.LibraryDaoImpl;
import com.lims.studentlogin.exception.LibraryException;



public class LibraryServiceImpl implements ILibraryService{
    ILibraryDao libraryDaoImpl=new LibraryDaoImpl();
	@Override
	public String getName(String id) throws LibraryException	{
		return libraryDaoImpl.getName(id);
	}
	
	@Override
	public int returnBook(String transactionId, String bookId) throws LibraryException
	{
		return libraryDaoImpl.returnBook(transactionId,bookId);
	}
	
	@Override
	public int isBookAvailable(String bookid) throws LibraryException
	{
		return libraryDaoImpl.isBookAvailable(bookid);
	}
	
	@Override
	public int addRequest(String userId, String bookId) throws LibraryException
	{
		return libraryDaoImpl.addRequest(userId, bookId);
	}

}
