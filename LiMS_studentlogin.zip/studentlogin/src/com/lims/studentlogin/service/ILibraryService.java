package com.lims.studentlogin.service;

import com.lims.studentlogin.exception.LibraryException;


public interface ILibraryService {
	public abstract String getName(String id) throws LibraryException;
	public abstract int returnBook(String transactionId, String bookId) throws LibraryException;
	public abstract int isBookAvailable(String bookid) throws LibraryException;
	public abstract int addRequest(String userId, String bookId) throws LibraryException;
}
