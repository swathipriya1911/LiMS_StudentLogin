package com.lims.studentlogin.dao;

public interface IQueryMapper {
	public static final String BOOKAVAILABILITY="SELECT no_of_copies FROM BooksInventory WHERE book_id=?";
	public static final String ADDUSER="INSERT INTO BooksRegistration VALUES(registration_seq.NEXTVAL,?,?,SYSDATE)";
}
