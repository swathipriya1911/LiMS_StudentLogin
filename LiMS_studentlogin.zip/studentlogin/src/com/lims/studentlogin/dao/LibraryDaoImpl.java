package com.lims.studentlogin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.lims.studentlogin.dao.IQueryMapper;
import com.lims.studentlogin.exception.LibraryException;
import com.lims.studentlogin.util.LibraryDBConnection;

public class LibraryDaoImpl implements ILibraryDao{

	@Override
	public String getName(String id) throws LibraryException{
		
			String name=null;
			Connection connection = LibraryDBConnection.getConnection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			try
			{
				preparedStatement = connection.prepareStatement("SELECT name FROM UserTable WHERE userid=?");
				preparedStatement.setString(1,id);
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next())
					name=resultSet.getString(1);
			}
			catch(SQLException sqlException)
			{
				throw new LibraryException("Caught "+sqlException.getMessage());
			}
			return name;
	      }
     
	@Override
	public int returnBook(String transactionId, String bookId) throws LibraryException
	{
		int fine=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		try
		{
			preparedStatement=connection.prepareStatement("update booktransaction set return_date=SYSDATE where transaction_id=?");
			preparedStatement.setString(1, transactionId);
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement=connection.prepareStatement("update booksInventory set no_of_copies=no_of_copies+1 where book_id=?");
			preparedStatement.setString(1, bookId);
			preparedStatement.executeUpdate();
			connection.commit();
			
			
			preparedStatement=connection.prepareStatement("select issue_date,return_date from booktransaction where transaction_id=?");
			preparedStatement.setString(1, transactionId);
			resultSet=preparedStatement.executeQuery();
			resultSet.next();
			Date issueDate=resultSet.getDate(1);
			Date returnDate=resultSet.getDate(2);
			
			int days=(int) ((issueDate.getTime()-returnDate.getTime())/(1000*60*60*24));
			
			if(days>30)
				fine=(days-30)*2;
			
			preparedStatement=connection.prepareStatement("update booktransaction set fine=? where transaction_id=?");
			preparedStatement.setInt(1, fine);
			preparedStatement.setString(2, transactionId);
			preparedStatement.executeUpdate();
			connection.commit();
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		return fine;
	}

	@Override
	public int isBookAvailable(String bookid) throws LibraryException
	{
		
		int status=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.BOOKAVAILABILITY);
			preparedStatement.setString(1,bookid);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				int copies=resultSet.getInt("no_of_copies");
				if(copies>0)
				{
					status=1;
				}
				else
				{
					status=2;
				}
			}
			else
				status=3;
			return status;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
	}
	
	@Override
	public int addRequest(String userId, String bookId) throws LibraryException
	{
		int registrationId=0;
		String bookIdTemp=null;
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT book_id FROM booksregistration WHERE user_id=?");
			preparedStatement.setString(1,userId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				bookIdTemp=resultSet.getString(1);
				if(bookId.equals(bookIdTemp))
				{
					registrationId=0;
					return registrationId;
				}
			}
				
			preparedStatement = connection.prepareStatement(IQueryMapper.ADDUSER);
			preparedStatement.setString(1,bookId);
			preparedStatement.setString(2,userId);
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement=connection.prepareStatement("SELECT registration_seq.CURRVAL FROM DUAL");
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			registrationId=rs.getInt(1);
			
			//System.out.println("User id is:"+registrationId);
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
		return registrationId;
	}

}
